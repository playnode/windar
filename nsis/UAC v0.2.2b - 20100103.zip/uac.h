//Copyright (C) Anders Kjersem. Licensed under the zlib/libpng license, see License.txt for details.
#pragma once
/** /#define BUILD_DBGRELEASE // Include simple debug output in release version */
/**/#define FEAT_CUSTOMRUNASDLG // Include custom runas dialog, used for broken Vista config */
/**/#define FEAT_CUSTOMRUNASDLG_TRANSLATE //*/
/**/#define FEAT_MSRUNASDLGMODHACK // Tweak RunAs dialog on NT5 */
/**/#define FEAT_AUTOPAGEJUMP //*/


#include "platform.h"
#include "NSIS_CUSTOMPISDK.h"
#include "util.h"

#if (defined(_MSC_VER) && !defined(_DEBUG))
	#pragma comment(linker,"/opt:nowin98")
	#pragma comment(linker,"/ignore:4078")
	#pragma comment(linker,"/merge:.rdata=.text")
#endif

#if 0
#	define BUILDRLSCANLEAK(x)
#else
#	define BUILDRLSCANLEAK(x) x
#endif

extern UINT_PTR StrToUInt(LPTSTR s,bool ForceHEX=false,BOOL*pFoundBadChar=0);

#ifdef FEAT_CUSTOMRUNASDLG
extern DWORD WINAPI MyRunAs(HINSTANCE hInstDll,SHELLEXECUTEINFO&sei); 
#endif


typedef BOOL	(WINAPI*ALLOWSETFOREGROUNDWINDOW)(DWORD dwProcessId);
typedef BOOL	(WINAPI*OPENPROCESSTOKEN)(HANDLE ProcessHandle,DWORD DesiredAccess,PHANDLE TokenHandle);
typedef BOOL	(WINAPI*OPENTHREADTOKEN)(HANDLE ThreadHandle,DWORD DesiredAccess,BOOL OpenAsSelf,PHANDLE TokenHandle);
typedef BOOL	(WINAPI*GETTOKENINFORMATION)(HANDLE hToken,TOKEN_INFORMATION_CLASS TokInfoClass,LPVOID TokInfo,DWORD TokInfoLenh,PDWORD RetLen);
typedef BOOL	(WINAPI*ALLOCATEANDINITIALIZESID)(PSID_IDENTIFIER_AUTHORITY pIdentifierAuthority,BYTE nSubAuthorityCount,DWORD sa0,DWORD sa1,DWORD sa2,DWORD sa3,DWORD sa4,DWORD sa5,DWORD sa6,DWORD sa7,PSID*pSid);
typedef PVOID	(WINAPI*FREESID)(PSID pSid);
typedef BOOL	(WINAPI*EQUALSID)(PSID pSid1,PSID pSid2);
typedef BOOL	(WINAPI*CHECKTOKENMEMBERSHIP)(HANDLE TokenHandle,PSID SidToCheck,PBOOL IsMember);
typedef BOOL	(WINAPI*CHANGEWINDOWMESSAGEFILTER)(UINT message,DWORD dwFlag);
#ifdef FEAT_CUSTOMRUNASDLG
typedef BOOL	(WINAPI*GETUSERNAME)(LPTSTR lpBuffer,LPDWORD nSize);
typedef BOOL	(WINAPI*CREATEPROCESSWITHLOGONW)(LPCWSTR lpUsername,LPCWSTR lpDomain,LPCWSTR lpPassword,DWORD dwLogonFlags,LPCWSTR lpApplicationName,LPWSTR lpCommandLine,DWORD dwCreationFlags,LPVOID pEnv,LPCWSTR WorkDir,LPSTARTUPINFOW pSI,LPPROCESS_INFORMATION pPI);
#define SECURITY_WIN32
#include <Security.h>//NameSamCompatible
typedef BOOLEAN	(WINAPI*GETUSERNAMEEX)(EXTENDED_NAME_FORMAT NameFormat,LPTSTR lpNameBuffer,PULONG nSize);
typedef DWORD	(WINAPI*SHGETVALUEA)(HKEY hKey,LPCSTR pszSubKey,LPCSTR pszValue,DWORD*pdwType,void*pvData,DWORD*pcbData);
#endif


#define UAC_SYNCREGISTERS 0x1
#define UAC_SYNCSTACK     0x2
#define UAC_SYNCOUTDIR    0x4
#define UAC_SYNCINSTDIR   0x8
#define UAC_CLEARERRFLAG  0x10

