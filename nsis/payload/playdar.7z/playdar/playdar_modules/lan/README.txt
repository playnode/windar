A resolver that broadcasts queries to the LAN using UDP multicast.
Results are streamed using normal HTTP to the LAN interface of the responder.

ie, you can find/play stuff off other machines on our LAN running playdar.
