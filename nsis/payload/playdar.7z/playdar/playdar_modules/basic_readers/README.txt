Provides strategies for handling the following protocols:
* file://  - for files on your local disk
* http://  - for streaming files from the web
